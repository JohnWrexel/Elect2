<?php
// Simulate a database with an array (you'll replace this with actual database queries)
$products = [
    ['id' => 1, 'name' => 'Xbox', 'price' => 100],
    ['id' => 2, 'name' => 'PS5', 'price' => 150]
];

// Function to get products from "database"
function getProductsFromDatabase() {
    global $products;
    return $products; // Simulated database query
}

// Function to add a new product
function addProductToDatabase($name, $price) {
    global $products;
    $newProduct = [
        'id' => count($products) + 1,
        'name' => $name,
        'price' => $price
    ];
    $products[] = $newProduct; // Simulated database insert
    return true; // Simulate success
}
?>

