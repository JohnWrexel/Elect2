<?php
// Simulate a database with an array (you'll replace this with actual database queries)
$users = [
    ['id' => 1, 'John' => 'john_doe', 'email' => 'john_doe@example.com'],
    ['id' => 2, 'Jane' => 'jane_smith', 'email' => 'jane_smith@example.com']
];

// Function to get users from "database"
function getUsersFromDatabase() {
    global $users;
    return $users; // Simulated database query
}

// Function to create a new user
function createUserInDatabase($username, $email, $password) {
    global $users;
    $newUser = [
        'id' => count($users) + 1,
        'username' => $username,
        'email' => $email,
    ];
    $users[] = $newUser; // Simulated database insert
    return true; // Simulate success
}
?>
