<?php
require_once 'config.php';

$log_file = 'logs/gateway.log';
$rate_dir = 'ratelimit_data/';
$path = $_GET['request_path'] ?? '';
$headers = getallheaders();
$api_key = $headers['X-API-Key'] ?? null;
$status_code = 200;

// API Key Validation
if (!$api_key || !array_key_exists($api_key, $valid_api_keys)) {
    $status_code = 401;
    http_response_code($status_code);
    echo json_encode(["error" => "Invalid or missing API Key"]);
    log_request($api_key, $path, $status_code);
    exit;
}

// Rate Limiting
$rate_file = $rate_dir . $api_key . '.json';
$limit = 10;
$window = 60; // 60 seconds
$now = time();

$data = file_exists($rate_file) ? json_decode(file_get_contents($rate_file), true) : ["timestamp" => $now, "count" => 0];

if (($now - $data['timestamp']) > $window) {
    $data = ["timestamp" => $now, "count" => 1];
} elseif ($data['count'] >= $limit) {
    $status_code = 429;
    http_response_code($status_code);
    echo json_encode(["error" => "Rate limit exceeded"]);
    log_request($api_key, $path, $status_code);
    exit;
} else {
    $data['count']++;
}

file_put_contents($rate_file, json_encode($data));

// Routing
switch ($path) {
    case 'users':
        include 'services/service_users.php';
        break;
    case 'products':
        include 'services/service_products.php';
        break;
    default:
        $status_code = 404;
        http_response_code($status_code);
        echo json_encode(["error" => "Endpoint not found"]);
}

log_request($api_key, $path, http_response_code());

// Logging Function
function log_request($api_key, $path, $status) {
    global $log_file;
    $entry = sprintf("[%s] - IP: %s - API Key: %s - Path: %s - Status: %d\n",
        date('Y-m-d H:i:s'),
        $_SERVER['REMOTE_ADDR'],
        $api_key ?? 'None',
        $path,
        $status
    );
    file_put_contents($log_file, $entry, FILE_APPEND);
}

